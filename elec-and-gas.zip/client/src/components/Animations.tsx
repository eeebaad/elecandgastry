/**
 * Custom animation utilities and components for Elec and Gas website
 * Provides smooth scroll animations, glowing effects, and micro-interactions
 */

import { useEffect, useState } from "react";

/**
 * Hook to detect when an element enters the viewport
 * Used for scroll-triggered animations
 */
export function useInView(ref: React.RefObject<HTMLElement>, options = {}) {
  const [isInView, setIsInView] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting) {
        setIsInView(true);
        observer.unobserve(entry.target);
      }
    }, { threshold: 0.1, ...options });

    if (ref.current) {
      observer.observe(ref.current);
    }

    return () => observer.disconnect();
  }, [ref, options]);

  return isInView;
}

/**
 * Smooth counter animation for statistics
 * Animates from 0 to target value over duration
 */
export function useCounter(target: number, duration = 2000) {
  const [count, setCount] = useState(0);

  useEffect(() => {
    let startTime: number;
    let animationId: number;

    const animate = (currentTime: number) => {
      if (!startTime) startTime = currentTime;
      const elapsed = currentTime - startTime;
      const progress = Math.min(elapsed / duration, 1);

      setCount(Math.floor(progress * target));

      if (progress < 1) {
        animationId = requestAnimationFrame(animate);
      }
    };

    animationId = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(animationId);
  }, [target, duration]);

  return count;
}

/**
 * CSS animation styles for glowing borders and effects
 * Add to your Tailwind CSS or global styles
 */
export const animationStyles = `
  @keyframes glow-border {
    0%, 100% {
      box-shadow: 0 0 20px rgba(88, 166, 255, 0.5), inset 0 0 20px rgba(88, 166, 255, 0.1);
    }
    50% {
      box-shadow: 0 0 30px rgba(88, 166, 255, 0.8), inset 0 0 30px rgba(88, 166, 255, 0.2);
    }
  }

  @keyframes glow-border-amber {
    0%, 100% {
      box-shadow: 0 0 20px rgba(255, 165, 0, 0.5), inset 0 0 20px rgba(255, 165, 0, 0.1);
    }
    50% {
      box-shadow: 0 0 30px rgba(255, 165, 0, 0.8), inset 0 0 30px rgba(255, 165, 0, 0.2);
    }
  }

  @keyframes fade-in-up {
    from {
      opacity: 0;
      transform: translateY(20px);
    }
    to {
      opacity: 1;
      transform: translateY(0);
    }
  }

  @keyframes fade-in-down {
    from {
      opacity: 0;
      transform: translateY(-20px);
    }
    to {
      opacity: 1;
      transform: translateY(0);
    }
  }

  @keyframes slide-in-left {
    from {
      opacity: 0;
      transform: translateX(-30px);
    }
    to {
      opacity: 1;
      transform: translateX(0);
    }
  }

  @keyframes slide-in-right {
    from {
      opacity: 0;
      transform: translateX(30px);
    }
    to {
      opacity: 1;
      transform: translateX(0);
    }
  }

  @keyframes pulse-glow {
    0%, 100% {
      opacity: 1;
    }
    50% {
      opacity: 0.7;
    }
  }

  .animate-glow-border {
    animation: glow-border 3s ease-in-out infinite;
  }

  .animate-glow-border-amber {
    animation: glow-border-amber 3s ease-in-out infinite;
  }

  .animate-fade-in-up {
    animation: fade-in-up 0.6s ease-out;
  }

  .animate-fade-in-down {
    animation: fade-in-down 0.6s ease-out;
  }

  .animate-slide-in-left {
    animation: slide-in-left 0.6s ease-out;
  }

  .animate-slide-in-right {
    animation: slide-in-right 0.6s ease-out;
  }

  .animate-pulse-glow {
    animation: pulse-glow 2s ease-in-out infinite;
  }
`;
