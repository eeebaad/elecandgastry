import { Button } from "@/components/ui/button";
import { useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";

/**
 * Elec and Gas - Premium Electrical & Gas Services Website
 * Design Philosophy: Dark mode with electric blue and amber accents
 * Features: Hero, Services, Service Area, Testimonials, Contact & Footer
 */

export default function Home() {
  const [scrollY, setScrollY] = useState(0);
  const heroRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleScroll = () => setScrollY(window.scrollY);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.6 },
    },
  };

  return (
    <div className="min-h-screen bg-background text-foreground overflow-hidden">
      {/* Navigation */}
      <nav className="fixed top-0 w-full z-50 bg-background/80 backdrop-blur-md border-b border-border">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <img
              src="/manus-storage/elec-gas-logo_25b95361.png"
              alt="Elec and Gas Logo"
              className="w-8 h-8"
            />
            <span className="font-bold text-lg" style={{ fontFamily: "Plus Jakarta Sans" }}>
              Elec and Gas
            </span>
          </div>
          <div className="hidden md:flex gap-8 text-sm">
            <a href="#services" className="hover:text-primary transition-colors">
              Services
            </a>
            <a href="#area" className="hover:text-primary transition-colors">
              Service Area
            </a>
            <a href="#testimonials" className="hover:text-primary transition-colors">
              Reviews
            </a>
            <a href="#contact" className="hover:text-primary transition-colors">
              Contact
            </a>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section
        ref={heroRef}
        className="relative min-h-screen flex items-center justify-center pt-20 overflow-hidden"
        style={{
          backgroundImage: "url('/manus-storage/hero-background_717f5944.png')",
          backgroundSize: "cover",
          backgroundPosition: "center",
          backgroundAttachment: "fixed",
        }}
      >
        {/* Dark overlay */}
        <div className="absolute inset-0 bg-gradient-to-b from-background/40 via-background/60 to-background" />

        {/* Animated background elements */}
        <div
          className="absolute top-20 right-10 w-72 h-72 bg-primary/10 rounded-full blur-3xl"
          style={{
            transform: `translateY(${scrollY * 0.5}px)`,
          }}
        />
        <div
          className="absolute bottom-20 left-10 w-96 h-96 bg-secondary/10 rounded-full blur-3xl"
          style={{
            transform: `translateY(${scrollY * 0.3}px)`,
          }}
        />

        <div className="relative z-10 container mx-auto px-4 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <div className="mb-6 inline-block">
              <div className="px-4 py-2 rounded-full border border-primary/50 bg-primary/10 backdrop-blur-sm">
                <span className="text-sm font-semibold text-primary">⚡ 10+ Years Experience</span>
              </div>
            </div>

            <h1
              className="text-5xl md:text-7xl font-bold mb-6 leading-tight"
              style={{ fontFamily: "Plus Jakarta Sans" }}
            >
              Trusted Electrical <br />
              <span className="bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
                & Gas Services
              </span>
            </h1>

            <p className="text-lg md:text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
              Professional installations, repairs, and certifications delivered with exceptional quality.
              Your safety is our priority.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a href="tel:+447861314414">
                <Button
                  size="lg"
                  className="w-full sm:w-auto bg-primary hover:bg-primary/90 text-primary-foreground font-semibold shadow-lg shadow-primary/30 hover:shadow-primary/50 transition-all duration-300"
                >
                  📞 Call Now: +44 7861314414
                </Button>
              </a>
              <a href="#contact">
                <Button
                  size="lg"
                  variant="outline"
                  className="w-full sm:w-auto border-primary/50 hover:border-primary hover:bg-primary/10 text-foreground font-semibold"
                >
                  Get a Free Quote
                </Button>
              </a>
            </div>
          </motion.div>
        </div>

        {/* Scroll indicator */}
        <motion.div
          className="absolute bottom-8 left-1/2 -translate-x-1/2"
          animate={{ y: [0, 10, 0] }}
          transition={{ duration: 2, repeat: Infinity }}
        >
          <div className="w-6 h-10 border-2 border-primary/50 rounded-full flex justify-center p-2">
            <div className="w-1 h-2 bg-primary rounded-full" />
          </div>
        </motion.div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-20 md:py-32 bg-background relative overflow-hidden">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true, margin: "-100px" }}
            className="text-center mb-16"
          >
            <h2
              className="text-4xl md:text-5xl font-bold mb-4"
              style={{ fontFamily: "Plus Jakarta Sans" }}
            >
              What We Do
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Comprehensive electrical and gas solutions for your home
            </p>
          </motion.div>

          <motion.div
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
            className="grid md:grid-cols-3 gap-8"
          >
            {/* Electrical Work Card */}
            <motion.div
              variants={itemVariants}
              className="group relative p-8 rounded-2xl bg-card/50 backdrop-blur-sm border border-border hover:border-primary/50 transition-all duration-300 hover:shadow-lg hover:shadow-primary/20 overflow-hidden"
            >
              <div className="absolute inset-0 bg-gradient-to-br from-primary/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              <div className="relative z-10">
                <div className="mb-6 w-16 h-16 rounded-xl bg-primary/20 flex items-center justify-center group-hover:bg-primary/30 transition-colors">
                  <img
                    src="/manus-storage/electrical-service-icon_1ce8ec2b.png"
                    alt="Electrical Services"
                    className="w-10 h-10"
                  />
                </div>
                <h3 className="text-2xl font-bold mb-4" style={{ fontFamily: "Plus Jakarta Sans" }}>
                  Electrical Work
                </h3>
                <p className="text-muted-foreground leading-relaxed">
                  Full rewires, consumer unit upgrades, fault finding, lighting installations, and EICR
                  certifications.
                </p>
              </div>
            </motion.div>

            {/* Gas Services Card */}
            <motion.div
              variants={itemVariants}
              className="group relative p-8 rounded-2xl bg-card/50 backdrop-blur-sm border border-border hover:border-secondary/50 transition-all duration-300 hover:shadow-lg hover:shadow-secondary/20 overflow-hidden"
            >
              <div className="absolute inset-0 bg-gradient-to-br from-secondary/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              <div className="relative z-10">
                <div className="mb-6 w-16 h-16 rounded-xl bg-secondary/20 flex items-center justify-center group-hover:bg-secondary/30 transition-colors">
                  <img
                    src="/manus-storage/gas-service-icon_2f4a0eee.png"
                    alt="Gas Services"
                    className="w-10 h-10"
                  />
                </div>
                <h3 className="text-2xl font-bold mb-4" style={{ fontFamily: "Plus Jakarta Sans" }}>
                  Gas Services
                </h3>
                <p className="text-muted-foreground leading-relaxed">
                  Boiler installations, servicing & repairs, gas safety inspections, central heating systems,
                  and landlord certificates.
                </p>
              </div>
            </motion.div>

            {/* Insulation Card */}
            <motion.div
              variants={itemVariants}
              className="group relative p-8 rounded-2xl bg-card/50 backdrop-blur-sm border border-border hover:border-chart-3/50 transition-all duration-300 hover:shadow-lg hover:shadow-chart-3/20 overflow-hidden"
            >
              <div className="absolute inset-0 bg-gradient-to-br from-chart-3/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              <div className="relative z-10">
                <div className="mb-6 w-16 h-16 rounded-xl bg-chart-3/20 flex items-center justify-center group-hover:bg-chart-3/30 transition-colors">
                  <img
                    src="/manus-storage/insulation-service-icon_860249e0.png"
                    alt="Insulation Services"
                    className="w-10 h-10"
                  />
                </div>
                <h3 className="text-2xl font-bold mb-4" style={{ fontFamily: "Plus Jakarta Sans" }}>
                  Insulation
                </h3>
                <p className="text-muted-foreground leading-relaxed">
                  Loft insulation, cavity wall insulation, and energy-efficient upgrades to lower your bills
                  and keep you warm.
                </p>
              </div>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Service Area Section */}
      <section id="area" className="py-20 md:py-32 bg-card/30 relative overflow-hidden">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true, margin: "-100px" }}
            className="text-center mb-16"
          >
            <h2
              className="text-4xl md:text-5xl font-bold mb-4"
              style={{ fontFamily: "Plus Jakarta Sans" }}
            >
              Our Service Area
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Based near Reading — covering a maximum 1.5-hour radius across Southern England for rapid,
              reliable response.
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 gap-12 items-center">
            {/* Service Area Map/Visual */}
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true, margin: "-100px" }}
              className="relative h-96 bg-gradient-to-br from-primary/20 to-secondary/20 rounded-2xl border border-border overflow-hidden"
            >
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center">
                  <div className="text-6xl mb-4">🗺️</div>
                  <p className="text-foreground font-semibold">Southern England Coverage</p>
                  <p className="text-muted-foreground text-sm mt-2">Reading-based, 1.5-hour radius</p>
                </div>
              </div>
            </motion.div>

            {/* Service Area Details */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true, margin: "-100px" }}
              className="space-y-6"
            >
              <div className="p-6 rounded-xl bg-card/50 border border-border hover:border-primary/50 transition-colors">
                <h3 className="text-xl font-bold mb-2 flex items-center gap-2">
                  <span className="text-2xl">⚡</span> Core HQ
                </h3>
                <p className="text-muted-foreground">Reading — Our home base, covering Berkshire and surrounding counties.</p>
              </div>

              <div className="p-6 rounded-xl bg-card/50 border border-border hover:border-primary/50 transition-colors">
                <h3 className="text-xl font-bold mb-2 flex items-center gap-2">
                  <span className="text-2xl">🚀</span> Key Covered Hubs
                </h3>
                <p className="text-muted-foreground">
                  London, Oxford, Swindon, Southampton, Milton Keynes, Guildford, Brighton
                </p>
              </div>

              <div className="p-6 rounded-xl bg-card/50 border border-border hover:border-primary/50 transition-colors">
                <h3 className="text-xl font-bold mb-2 flex items-center gap-2">
                  <span className="text-2xl">⏱️</span> Fast Response
                </h3>
                <p className="text-muted-foreground">
                  Quick turnaround on quotes and emergency appointments across our full coverage zone.
                </p>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section id="testimonials" className="py-20 md:py-32 bg-background relative overflow-hidden">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true, margin: "-100px" }}
            className="text-center mb-16"
          >
            <h2
              className="text-4xl md:text-5xl font-bold mb-4"
              style={{ fontFamily: "Plus Jakarta Sans" }}
            >
              What Our Customers Say
            </h2>
            <p className="text-lg text-muted-foreground">Rated 5 stars across the board</p>
          </motion.div>

          <motion.div
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
            className="grid md:grid-cols-3 gap-8"
          >
            {/* Review 1 */}
            <motion.div
              variants={itemVariants}
              className="p-8 rounded-2xl bg-card/50 backdrop-blur-sm border border-border hover:border-primary/50 transition-all duration-300 hover:shadow-lg hover:shadow-primary/20"
            >
              <div className="flex gap-1 mb-4">
                {[...Array(5)].map((_, i) => (
                  <span key={i} className="text-xl">
                    ⭐
                  </span>
                ))}
              </div>
              <p className="text-foreground mb-6 leading-relaxed">
                "Very high quality work throughout. Had our full loft insulation done and the difference is
                night and day — the house stays so much warmer now. Incredibly professional and tidy, would
                highly recommend Elecandgas to anyone."
              </p>
              <div className="pt-4 border-t border-border">
                <p className="font-semibold">James T.</p>
                <p className="text-sm text-muted-foreground">Reading, Berkshire</p>
              </div>
            </motion.div>

            {/* Review 2 */}
            <motion.div
              variants={itemVariants}
              className="p-8 rounded-2xl bg-card/50 backdrop-blur-sm border border-border hover:border-secondary/50 transition-all duration-300 hover:shadow-lg hover:shadow-secondary/20"
            >
              <div className="flex gap-1 mb-4">
                {[...Array(5)].map((_, i) => (
                  <span key={i} className="text-xl">
                    ⭐
                  </span>
                ))}
              </div>
              <p className="text-foreground mb-6 leading-relaxed">
                "Brilliant service from start to finish. Had a new boiler installed and the whole process was
                seamless. The engineer explained everything clearly, left the place spotless, and the price was
                very fair. Top-notch gas work."
              </p>
              <div className="pt-4 border-t border-border">
                <p className="font-semibold">Sarah P.</p>
                <p className="text-sm text-muted-foreground">Oxford, Oxfordshire</p>
              </div>
            </motion.div>

            {/* Review 3 */}
            <motion.div
              variants={itemVariants}
              className="p-8 rounded-2xl bg-card/50 backdrop-blur-sm border border-border hover:border-chart-3/50 transition-all duration-300 hover:shadow-lg hover:shadow-chart-3/20"
            >
              <div className="flex gap-1 mb-4">
                {[...Array(5)].map((_, i) => (
                  <span key={i} className="text-xl">
                    ⭐
                  </span>
                ))}
              </div>
              <p className="text-foreground mb-6 leading-relaxed">
                "Called Elecandgas for an emergency electrical fault and they were out within hours. Found the
                issue quickly, rewired the problem area, and gave us a full safety certificate. Absolute
                lifesavers — wouldn't use anyone else!"
              </p>
              <div className="pt-4 border-t border-border">
                <p className="font-semibold">Mark K.</p>
                <p className="text-sm text-muted-foreground">Guildford, Surrey</p>
              </div>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 md:py-32 bg-card/30 relative overflow-hidden">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true, margin: "-100px" }}
            className="text-center mb-16"
          >
            <h2
              className="text-4xl md:text-5xl font-bold mb-4"
              style={{ fontFamily: "Plus Jakarta Sans" }}
            >
              Get In Touch
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              We're available by phone and email — reach out for a free, no-obligation quote.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true, margin: "-100px" }}
            className="max-w-2xl mx-auto"
          >
            <div className="grid md:grid-cols-2 gap-8 mb-12">
              {/* Phone Card */}
              <a href="tel:+447861314414">
                <div className="p-8 rounded-2xl bg-gradient-to-br from-primary/20 to-primary/10 border border-primary/50 hover:border-primary transition-all duration-300 hover:shadow-lg hover:shadow-primary/30 cursor-pointer h-full">
                  <div className="text-4xl mb-4">📞</div>
                  <h3 className="text-2xl font-bold mb-2">Call Now</h3>
                  <p className="text-primary font-semibold text-lg">+44 7861314414</p>
                </div>
              </a>

              {/* Email Card */}
              <a href="mailto:elecandgasuk@gmail.com">
                <div className="p-8 rounded-2xl bg-gradient-to-br from-secondary/20 to-secondary/10 border border-secondary/50 hover:border-secondary transition-all duration-300 hover:shadow-lg hover:shadow-secondary/30 cursor-pointer h-full">
                  <div className="text-4xl mb-4">📧</div>
                  <h3 className="text-2xl font-bold mb-2">Email</h3>
                  <p className="text-secondary font-semibold">elecandgasuk@gmail.com</p>
                </div>
              </a>
            </div>

            {/* Contact Form */}
            <div className="p-8 rounded-2xl bg-card/50 backdrop-blur-sm border border-border">
              <form className="space-y-6" onSubmit={(e) => e.preventDefault()}>
                <div className="grid md:grid-cols-2 gap-4">
                  <input
                    type="text"
                    placeholder="Your Name"
                    className="px-4 py-3 rounded-lg bg-background border border-border focus:border-primary focus:outline-none transition-colors"
                    required
                  />
                  <input
                    type="email"
                    placeholder="Your Email"
                    className="px-4 py-3 rounded-lg bg-background border border-border focus:border-primary focus:outline-none transition-colors"
                    required
                  />
                </div>
                <input
                  type="tel"
                  placeholder="Your Phone"
                  className="w-full px-4 py-3 rounded-lg bg-background border border-border focus:border-primary focus:outline-none transition-colors"
                  required
                />
                <select
                  className="w-full px-4 py-3 rounded-lg bg-background border border-border focus:border-primary focus:outline-none transition-colors text-foreground"
                  required
                >
                  <option value="">Select Service Needed</option>
                  <option value="electrical">Electrical Work</option>
                  <option value="gas">Gas Services</option>
                  <option value="insulation">Insulation</option>
                  <option value="other">Other</option>
                </select>
                <textarea
                  placeholder="Your Message"
                  rows={5}
                  className="w-full px-4 py-3 rounded-lg bg-background border border-border focus:border-primary focus:outline-none transition-colors resize-none"
                />
                <Button
                  type="submit"
                  size="lg"
                  className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-semibold shadow-lg shadow-primary/30 hover:shadow-primary/50 transition-all duration-300"
                >
                  Send Message
                </Button>
              </form>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-card/50 border-t border-border py-12">
        <div className="container mx-auto px-4 text-center text-muted-foreground">
          <p>© 2026 Elecandgas. All rights reserved.</p>
          <p className="text-sm mt-2">Built with premium design and cutting-edge technology</p>
        </div>
      </footer>
    </div>
  );
}
