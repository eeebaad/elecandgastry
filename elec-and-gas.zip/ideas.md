# Elec and Gas - Design Philosophy

## Design Approach: Premium Tech-Forward Trade Services

This website embodies a **modern, high-tech aesthetic** for a premium electrical and gas services company. The design moves away from generic trade-service websites and instead positions Elec and Gas as a **cutting-edge, trustworthy, professional** service provider.

### Design Movement
**Cyberpunk Minimalism meets Professional Elegance** — combining sleek, futuristic neon accents with clean, sophisticated layouts. Inspired by modern SaaS dashboards and premium tech brands.

### Core Principles
1. **Dark-First Sophistication:** Deep, rich dark backgrounds (carbon, midnight gray) create premium perception and reduce cognitive load
2. **Neon Accents as Trust Markers:** Electric blue (electricity) and vibrant amber/orange (gas/heat) serve as visual metaphors for services while creating visual hierarchy
3. **Glassmorphism & Depth:** Subtle backdrop-blur effects, layered cards, and soft shadows create dimensional depth without clutter
4. **Micro-interactions Everywhere:** Smooth hover states, glowing borders, and scroll animations make the interface feel alive and responsive

### Color Philosophy
- **Primary Dark:** `oklch(0.12 0.01 280)` — Deep midnight, professional foundation
- **Electric Blue:** `oklch(0.55 0.24 260)` — Represents electricity, trust, and modernity
- **Vibrant Amber:** `oklch(0.65 0.22 50)` — Represents gas/heat, energy, warmth
- **Accent Green:** `oklch(0.60 0.18 140)` — Eco-efficiency for insulation services
- **Text Light:** `oklch(0.92 0.01 280)` — High contrast, readable on dark backgrounds

**Emotional Intent:** The dark background conveys professionalism and trust; neon accents create energy and modernity; together they position Elec and Gas as both reliable AND innovative.

### Layout Paradigm
**Asymmetric Bento-Grid with Organic Flow** — Avoid centered, symmetrical layouts. Use:
- Staggered card arrangements in the services section
- Offset hero text with visual breathing room
- Asymmetric testimonial carousel
- Organic, flowing transitions between sections

### Signature Elements
1. **Neon Glow Borders:** Cards and buttons feature glowing borders on hover (electric blue or amber)
2. **Lightning & Flame Motifs:** Subtle SVG icons representing electricity and gas throughout
3. **Glassmorphic Cards:** Semi-transparent backgrounds with backdrop-blur for layered depth

### Interaction Philosophy
- **Hover = Activation:** All interactive elements glow, scale subtly, or shift when hovered
- **Scroll = Reveal:** Cards fade in and stagger-reveal as the user scrolls
- **Click = Feedback:** Buttons scale down on press, providing tactile feedback
- **Smooth Transitions:** All animations use snappy ease-out curves (180–250ms)

### Animation Guidelines
- **Entrance Animations:** Fade-in + slight scale-up (from 0.95 to 1) with 150–200ms duration
- **Hover States:** Glow effect, subtle scale (1 to 1.02), and border color shift
- **Scroll Reveals:** Stagger by 50–80ms per card for cascading effect
- **Parallax:** Subtle background movement on scroll for depth
- **Counters:** Smooth number transitions for statistics

### Typography System
- **Display Font:** `Plus Jakarta Sans` (bold, 700–800 weight) for headlines — modern, geometric, commanding
- **Body Font:** `Inter` (regular, 400–500 weight) for body text — clean, readable, professional
- **Hierarchy:** 
  - H1: 48px, 700 weight (hero title)
  - H2: 36px, 700 weight (section headlines)
  - H3: 24px, 600 weight (card titles)
  - Body: 16px, 400 weight
  - Small: 14px, 400 weight

### Brand Essence
**One-line positioning:** "Trusted, modern electrical and gas services delivered with cutting-edge professionalism and exceptional quality."

**Personality adjectives:** Reliable, Innovative, Professional

### Brand Voice
- **Headlines:** Direct, confident, benefit-focused (e.g., "Your Safety is Our Priority" not "Welcome to Elec and Gas")
- **CTAs:** Action-oriented, urgent but not pushy (e.g., "Call Now" or "Get a Free Quote")
- **Microcopy:** Clear, jargon-free, reassuring (e.g., "10+ Years Experience" not "Established Since 2015")

**Example lines:**
- "Professional installations, repairs, and certifications delivered with exceptional quality."
- "Based near Reading — covering a maximum 1.5-hour radius across Southern England for rapid, reliable response."

### Logo & Wordmark
**Concept:** A bold, geometric lightning bolt combined with a subtle flame shape, forming a unified symbol. The mark should be:
- Symmetrical and modern
- Easily recognizable at small sizes
- Incorporate both electric blue and amber colors
- No text in the mark itself (wordmark separate)

### Signature Brand Color
**Electric Blue:** `oklch(0.55 0.24 260)` — Unmistakably Elec and Gas. Used for primary CTAs, glowing borders, and trust badges.

---

## Implementation Notes
- Use Tailwind CSS 4 with custom OKLCH color variables
- Implement all animations with CSS transitions and Framer Motion for complex sequences
- Ensure full responsiveness: mobile-first design with breakpoints at 640px, 1024px, 1280px
- Test all animations with `prefers-reduced-motion` for accessibility
- Validate contrast ratios for all text on dark backgrounds (WCAG AA minimum)
